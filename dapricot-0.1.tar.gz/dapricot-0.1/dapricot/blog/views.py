from django.http import Http404
from django.shortcuts import render
from django.core.paginator import Paginator
from django.conf import settings

from .models import Post, Category, Tag, Comment, Commenter
from .forms import CommentForm, CommenterForm, CommentCommenterForm
from django.core.exceptions import ValidationError

from django.core.mail import send_mail

def post(request, day, month, year, slug):
    post = Post.objects.filter(publication_date__year=year,
                publication_date__month=month,
                publication_date__day=day)
    for p in post:
        comments = Comment.objects.filter(post=p)
        if p.slug==slug:
            if (p.author==request.user and p.status=='d') or p.status=='p':
                
                if request.method == "POST":
                    form = CommentCommenterForm(request.POST)
                    
                    if form.is_valid():
                        
                        try:
                            c = Commenter.objects.get(nickname=form.data['nickname'], 
                              email=form.data['email'])
                            cc = Comment(content=form.data['content'],author=c, post=p)
                            cc.save()
                            form = CommentCommenterForm()                    
                        except:
                            
                            try:
                                c = Commenter(nickname=form.data['nickname'], 
                                      email=form.data['email'])
                                c.save()
                                #send_mail('subject', 'body of the message', settings.EMAIL_HOST_USER, [c.email])
                                cc = Comment(content=form.data['content'],
                                    author=c, post=p)
                                cc.save()
                                form = CommentCommenterForm()
                            except:
                                form.add_error(None, ValidationError(
                                    "El nickname o el correo ya se encuentran registrados. <a>¿No recuerdas tu nickname?</a>"
                                    ))
                else:
                    form = CommentCommenterForm()
                    
                return render(request, 'blog/post.html', {
                    'post': p,
                    'comments': comments,
                    'form': form
                    })
    
    raise Http404("Post does not exist")

def filterList(request, filter_name):
    
    if filter_name=='category':
        filter_list = Category.objects.all()
    elif filter_name=='tag':
        filter_list = Tag.objects.all()
    
    if filter_list:
        return render(request, 'blog/filter_list.html', {
            'filter_list':filter_list,
            'filter_name': filter_name
        })
    
    raise Http404("Poll does not exist")

def postList(request, filter_name=None, value=None, page=1):
    post_list = Post.objects.filter(status='p').order_by('-publication_date')
    filter_value = None
    if filter_name=='category':
        categories = Category.objects.all()
        for c in categories:
            if c.slug==value:
                filter_value = c
        post_list = post_list.filter(category__name=filter_value.name)
        
    elif filter_name=='tag':
        tags = Tag.objects.all()
        
        for t in tags:
            if t.slug==value:
                filter_value = t
        post_list = post_list.filter(tags__name=filter_value.name)
    
    paginator = Paginator(post_list, 10)
    list_page = paginator.get_page(page)
    
    data = { 'post_list':list_page }
    template = 'blog/main_site.html'
    
    if filter_name:
        data.update({ 'filter': [filter_name, filter_value] })
        template = 'blog/post_list.html'
        
    return render(request, template, {
        'post_list':list_page,
        'filter': [filter_name, filter_value]
    })
    
    raise Http404("Poll does not exist")
