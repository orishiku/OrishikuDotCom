from django.db import models
from django.db.models.signals import post_save
from django.utils.text import slugify
from django.utils.html import strip_tags
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _
from django.contrib.sites.models import Site

from django.contrib.auth import get_user_model
from django.dispatch.dispatcher import receiver


ENTRY_STATUS_OPTIONS = (
    ('d','Draft'),
    ('p','Published'),
)
STATUS_COMMENT_OPTIONS = (
    ('a', 'Approved'),
    ('u', 'Under approvement'),)

STATUS_COMMENTER_OPTIONS = (
    ('v', 'Verified'),
    ('u', 'Under verification'),)

class Post(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, blank=True)
    content = models.TextField()
    
    category = models.ForeignKey('Category', 
                                        on_delete=models.SET_NULL, 
                                        null=True)
    tags   = models.ManyToManyField('Tag')
    status = models.CharField(choices=ENTRY_STATUS_OPTIONS, 
                                       max_length=1)
    enable_comments = models.BooleanField(_('enable comments'), default=False)
    
    author = models.ForeignKey(
        get_user_model(),
        on_delete=models.SET_NULL,
        null=True, editable=False)
    
    creation_date = models.DateTimeField(auto_now_add=True, editable=False)
    last_edition_date = models.DateTimeField(auto_now=True, editable=False)
    publication_date = models.DateTimeField(editable=False, null=True)

    @property
    def get_preview(self):
        preview_content = self.content.split('</p>')
        preview_content = strip_tags(preview_content[0])
        preview_content = preview_content[0:1000]
        
        return preview_content
    
    @property
    def permalink(self):
        current_site = Site.objects.get_current()
        date=self.publication_date
        if date != None:
            permalink = '/{0}/{1}/{2}/{3}'.format(
                date.day, date.month, date.year,
                self.slug)
            url = "<a href='{1}'>{1}</a>".format(
                current_site,permalink)
            return mark_safe(url)
        else:
            return None
            '''
    def save(self, *args, **kwargs):
        title = getattr(self, 'title')
        t = slugify(title)[0:40]
        post_id = getattr(self, 'id')
        
        self.slug = "{0}_{1}".format(t, post_id)        
        super(Post, self).save(*args, **kwargs)
    '''
    class Meta:
        verbose_name = _('post')
        verbose_name_plural = _('posts')
        ordering = ('creation_date',)
        db_table = 'dapricot_blog_post'
        
    def __str__(self):
        return self.title
    
@receiver(post_save, sender=Post)
def post_slug(sender, instance, created, **kwargs):
    title = slugify(instance.title)[0:40]
    instance.slug = "{0}_{1}".format(title, instance.id)    
    if created:
        instance.save()

'''
'''
class Category(models.Model):
    name = models.CharField(max_length=50)
    slug = models.SlugField(max_length=50, blank=True)
    
    def save(self, *args, **kwargs):
        name = getattr(self, 'name')
        self.slug = slugify(name)
        
        super(Category, self).save(*args, **kwargs)
        
    class Meta:
        verbose_name = _('category')
        verbose_name_plural = _('categories')
        db_table = 'dapricot_blog_category'
        
    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=50)
    slug = models.SlugField(max_length=50, blank=True)
    
    def save(self, *args, **kwargs):
        name = getattr(self, 'name')
        self.slug = slugify(name)
        
        super(Tag, self).save(*args, **kwargs)
        
    class Meta:
        verbose_name = _('tag')
        verbose_name_plural = _('tags')
        db_table = 'dapricot_blog_tag'
        
    def __str__(self):
        return self.name
    
class Commenter(models.Model):
    nickname = models.CharField(max_length=50, unique=True)
    email = models.EmailField(max_length=50, unique=True)
    
    status = models.CharField(
        choices=STATUS_COMMENTER_OPTIONS, 
        max_length=1, 
        default='u', 
        editable=False)
        
    class Meta:
        verbose_name = _('commenter')
        verbose_name_plural = _('commentators')
        db_table = 'dapricot_blog_commenter'
    
class Comment(models.Model):
    content = models.CharField(max_length=500)
    post = models.ForeignKey('Post', on_delete=models.CASCADE)
    author = models.ForeignKey('Commenter', on_delete=models.CASCADE)
    answer_to = models.ForeignKey('self', on_delete=models.CASCADE, null=True, editable=False)
    status = models.CharField(
        choices=STATUS_COMMENT_OPTIONS, 
        max_length=1, 
        default='u')
    creation_date = models.DateTimeField(auto_now_add=True, editable=False)
    
    class Meta:
        verbose_name = _('comment')
        verbose_name_plural = _('comments')
        ordering = ('creation_date',)
        db_table = 'dapricot_blog_comment'
    