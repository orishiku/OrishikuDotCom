from django import forms
from django.forms import ModelForm
from .models import Comment, Commenter

class CommentForm(ModelForm):
    
    class Meta:
        model = Comment
        fields = '__all__'
        
class CommenterForm(ModelForm):
    
    class Meta:
        model = Commenter
        fields = '__all__'
        
class CommentCommenterForm(forms.Form):
    nickname = forms.CharField(max_length=50)
    email = forms.EmailField(max_length=50)
    content = forms.CharField(max_length=500)